#
# Author : Christian Howard
# Purpose: Script to tackle Homework 3 Problem 4
#           which is about classification of pools


# import useful libraries

# import personal libraries
import hw3.p4soln           as p4soln

if __name__ == "__main__":

    # run attempt at solving problem 4 in hw 3
    p4soln.attempt3()
